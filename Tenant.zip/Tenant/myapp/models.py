# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

#from phonenumber_field.modelfields import PhoneNumberField
# Create your models here.

class tenant_data(models.Model):
    Name      =  models.CharField(max_length=100)
    Age       =  models.IntegerField()
    gender_choices=[('M','Male'),('F','Female'),('O','Others')]
    Gender    =  models.CharField(max_length=1,choices=gender_choices)
    mobile_1  =  models.CharField(max_length=100)
    mobile_2  =  models.CharField(max_length=100)
    mobile_3  =  models.CharField(max_length=100)
    address_1 =  models.CharField(max_length=100)
    city      =  models.CharField(max_length=100)
    country   =  models.CharField(max_length=100)
    location  =  models.CharField(max_length=100)

    def __str__(self):
        return self.Name
