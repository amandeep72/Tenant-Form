# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,HttpResponse,HttpResponseRedirect,reverse

from .forms import TenantForm
from .models import tenant_data
# Create your views here.
'''
def tenant(request):
    if request.method =="POST":
        my_form=tenant_form(request.POST)
        if my_form.is_valid():
            my_form.save()
            return HttpResponseRedirect('tenant')
    else:
        my_form=tenant_form()
        return HttpResponse("is not a POST request hlooooooooo")
'''

def  new(request):
    #return HttpResponse("okkkkkkkkkkkkkkkkk ho gya")
    if request.method =="POST":
        my_form=TenantForm(request.POST)
        if my_form.is_valid():
            my_form.save()
            return HttpResponseRedirect(reverse('homepage'))
    else:
        my_form=TenantForm()

        return render(request,'myapp/tenant.html',{'my_form':my_form})


def homepage(request):
    a=tenant_data.objects.all()
    print (a)
    for i in a:
        print (i.Name)
    return render(request,'myapp/homepage.html',{'user':a})

from django.shortcuts import get_list_or_404, get_object_or_404

def edit(request,id=None):
    edit_user=get_object_or_404(tenant_data,id=id)
    print ("user iss   is ::: ",edit_user)
    if request.method=="POST":
        my_form=TenantForm(request.POST,instance=edit_user)
        if my_form.is_valid():
            my_form.save()
            return HttpResponseRedirect(reverse('homepage'))
    else:
        tenant_form=TenantForm(instance=edit_user)
        return render (request,'myapp/edit.html',{'my_form':tenant_form})


def details(request,id=None):
    details=get_object_or_404(tenant_data,id=id)
    tenant_form=TenantForm(instance=details)
    print ("details are :::: ",tenant_form)
    return render(request,'myapp/details.html',{'details':tenant_form})

def delete(request,id=None):
    user_details=get_object_or_404(tenant_data,id=id)
    if request.method=="POST":
        user_details.delete()
        return HttpResponseRedirect(reverse('homepage'))
    else:
        return render(request,'myapp/delete.html',{'details':user_details})
