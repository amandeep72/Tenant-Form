from django import forms

from .models import tenant_data

class TenantForm(forms.ModelForm):
    '''
    Name      =  forms.CharField(max_length=100)
    Age       =  forms.IntegerField(max_length=100)
    gender_choices=[('M','Male'),('F','Female'),('O','Others')]
    Gender    =  forms.CharField(max_length=1,choices=gender_choices)
    mobile_1  =  forms.CharField(max_length=100)
    mobile_2  =  forms.CharField(max_length=100)
    mobile_3  =  forms.CharField(max_length=100)
    address_1 =  forms.CharField(max_length=100)
    city      =  forms.CharField(max_length=100)
    country   =  forms.CharField(max_length=100)
    location  =  forms.CharField(max_length=100)
    date      =  forms.DateTimeField(auto_now=True)
'''

    class Meta:
        model = tenant_data
        fields = ('Name', 'Age','Gender','mobile_1','mobile_2','mobile_3','address_1','city','country','location')
        excludes = ['']
