$(document).ready(function () {
  $('.course-link').click(function() {
      var task_id = $(this).attr('id');
      var url = "http://localhost:8090/homepage/course_content/"; //THIS NEEDS TO BE THE URL TO YOUR VIEW
      var data = {'task_id': task_id};
      //var success = function () {
      //    console.log('yay');
      //};
      $.ajax({
           type: "GET",
           url: url,
           data: data,
           success: success
      });

  });
});
