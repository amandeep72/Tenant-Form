
function myFunction() {
  document.getElementById("demo").innerHTML="Completed";
}


// function to add new list onclick
function add_new_lec()
{
}
