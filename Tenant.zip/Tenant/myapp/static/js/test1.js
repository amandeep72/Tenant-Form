function myFunction() {
  document.getElementById("demo").innerHTML = "Hello World";
}


$(document).ready(function()
{
     var i=1;
    $("#add_row").click(function()
    {
       $('#addr'+i).html("<td>"+ (i+1) +"</td><td><input name='name"+i+"' type='text' placeholder='Name' class='form-control input-md'  />");
       $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
    i++;
});

});
