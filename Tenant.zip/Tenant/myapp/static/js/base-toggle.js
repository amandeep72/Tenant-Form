$(document).ready(function () {
    $('#menu-toggle').on('click', function () {
        $('#wrapper').toggleClass('toggled');
    });
});
